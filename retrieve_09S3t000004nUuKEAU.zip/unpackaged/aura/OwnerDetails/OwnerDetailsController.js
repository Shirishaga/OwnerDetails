({
	doInIt : function(component, event, helper) {
		helper.getUser(component, event, helper)
	}
})